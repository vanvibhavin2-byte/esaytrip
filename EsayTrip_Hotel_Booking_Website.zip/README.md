# EsayTrip

Free hotel-booking website starter built with React + Vite.

## Run
1. Install Node.js (18+ recommended).
2. Open this folder in terminal.
3. Run:
   npm install
   npm run dev
4. Open the local URL shown by Vite.

## Included
- Hotel search/filter
- Destination, dates, guests
- Hotel cards and details
- Room selection
- Booking form
- Confirmation page
- Responsive mobile design
- Local demo booking storage

## For a real production booking platform
Connect a backend/database, authentication, payment gateway, hotel inventory/API, email/SMS notifications, and an admin dashboard. The current project is a frontend demo and does not process real payments.
